self.__precacheManifest = [
  {
    "url": "./js/common.bundle.180bf71db02907105f43.js"
  },
  {
    "url": "./js/app.bundle.4db0640fd744cd24263d.js"
  },
  {
    "url": "./js/another.bundle.44aa0313e937cd6f62cb.js"
  },
  {
    "revision": "e28ff4a2ec7360ec3ca03d45196b8ec0",
    "url": "./index.html"
  },
  {
    "url": "./img/5b1e3a536c7bb0df157fa9963dd303a0.jpg"
  },
  {
    "url": "./fonts/d41d8cd98f00b204e9800998ecf8427e.woff2"
  },
  {
    "url": "./fonts/d41d8cd98f00b204e9800998ecf8427e.woff"
  }
];